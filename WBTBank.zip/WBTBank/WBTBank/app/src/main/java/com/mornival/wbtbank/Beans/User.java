package com.mornival.wbtbank.Beans;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.UUID;

public class User {

    private int id;
    private String name = null;
    private String password = null;
    private Role role;
    private String key;
    private String email = null;
    private String phone = null;
    private String inn = null;
    private String birthday;
    private String passport = null;
    private String codeStaff = null;
    private String sex;

    private static User instance = null;
    SharedPreferences preferences;

    private User(Context context){
        preferences = context.getSharedPreferences("user_data", Context.MODE_PRIVATE);
        if (preferences.getString("user_key", "").isEmpty()){
            key = UUID.randomUUID().toString();
            //preferences.edit().putString("user_key", key).apply();

        } else {
            id = preferences.getInt("id", 0);
            name = preferences.getString("username", "");
            email = preferences.getString("email", "");
            password = preferences.getString("password", "");
            key = preferences.getString("user_key","");
            //взять из preferences данные о пользователе
        }

    }

    public static User getInstance(Context context){
        if(instance == null){
            instance = new User(context);
        }

        return instance;
    }

    public boolean IsValidUser(){
        if(codeStaff != null){
            instance.setRole(Role.STAFF);
        }else
            instance.setRole(Role.CLIENT);

        return     instance.name != null
                && instance.email != null
                && instance.phone != null
                && instance.inn != null
                && instance.passport != null
                && instance.password != null
                && instance.key != null;
    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        preferences.edit().putInt("id", id).apply();
        this.id = id;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        preferences.edit().putString("username", name).apply();
        this.name = name;
    }

    public Role getRole() {
        return role;
    }

    private void setRole(Role role) {
        this.role = role;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        preferences.edit().putString("email", email).apply();
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getInn() {
        return inn;
    }

    public void setInn(String inn) {
        this.inn = inn;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getPassport() {
        return passport;
    }

    public void setPassport(String passport) {
        this.passport = passport;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getCodeStaff() {
        return codeStaff;
    }

    public void setCodeStaff(String codeStaff) {
        this.codeStaff = codeStaff;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        preferences.edit().putString("password", password).apply();
        this.password = password;
    }
}
