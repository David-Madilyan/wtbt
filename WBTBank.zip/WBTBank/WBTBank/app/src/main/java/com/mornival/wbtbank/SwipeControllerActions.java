package com.mornival.wbtbank;

public abstract class SwipeControllerActions {
    public void onRightClicked(int position) {}
}
