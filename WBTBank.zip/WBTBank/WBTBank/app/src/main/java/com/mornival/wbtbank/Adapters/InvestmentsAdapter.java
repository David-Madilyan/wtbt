package com.mornival.wbtbank.Adapters;

public class InvestmentsAdapter {
}
