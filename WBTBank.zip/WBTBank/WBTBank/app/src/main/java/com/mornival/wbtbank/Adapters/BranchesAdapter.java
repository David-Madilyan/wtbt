package com.mornival.wbtbank.Adapters;

public class BranchesAdapter {
}
