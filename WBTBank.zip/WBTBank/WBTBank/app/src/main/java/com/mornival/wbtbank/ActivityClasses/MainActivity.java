package com.mornival.wbtbank.ActivityClasses;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.mornival.wbtbank.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        https://codeburst.io/android-swipe-menu-with-recyclerview-8f28a235ff28
//        https://github.com/FanFataL/swipe-controller-demo
    }
}
