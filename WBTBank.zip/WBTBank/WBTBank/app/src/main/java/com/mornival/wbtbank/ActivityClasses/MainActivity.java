package com.mornival.wbtbank.ActivityClasses;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.mornival.wbtbank.Beans.Role;
import com.mornival.wbtbank.Beans.User;
import com.mornival.wbtbank.Callbacks;
import com.mornival.wbtbank.ClientsActivity;
import com.mornival.wbtbank.Database.AuthController;
import com.mornival.wbtbank.Database.ConnectorAsync;
import com.mornival.wbtbank.R;

import java.sql.Connection;


//        https://codeburst.io/android-swipe-menu-with-recyclerview-8f28a235ff28
//        https://github.com/FanFataL/swipe-controller-demo

public class MainActivity extends AppCompatActivity implements Callbacks.AuthorizationToDb {
    User user;
    Context context;
    Connection connect;
    ProgressBar progressBar;
    NavigationView navigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);
        context = this;
        user  = User.getInstance(this);

        DrawerLayout drawer = findViewById(R.id.drawer_main);
        navigationView = findViewById(R.id.navigationViewMain);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.short_name, R.string.short_name);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        if(user.getRole() == Role.STAFF){
            navigationView.inflateMenu(R.menu.menu_staff);
            navigationView.setNavigationItemSelectedListener(menuItem -> {
                if (menuItem.getItemId() == R.id.clients) {
                    Intent intent = new Intent(this, ClientsActivity.class);
                    startActivity(intent);
                }
                if(menuItem.getItemId() == R.id.credit_work){
                    Intent intent = new Intent(this, CreditsActivity.class);
                    startActivity(intent);
                }
                if(menuItem.getItemId() == R.id.branches_work){
                    Intent intent = new Intent(this, BranchesActivity.class);
                    startActivity(intent);
                }
                if(menuItem.getItemId() == R.id.exit_account_s){
                    Intent intent = new Intent(this, AuthActivity.class);
                    intent.putExtra("exit_user", true);
                    startActivity(intent);
                }
                return false;
            });

        }else{                                                                                      /*иначе открывается меню для обычных пользователей (клиентов банка)*/
            navigationView.setNavigationItemSelectedListener(menuItem -> {
                if (menuItem.getItemId() == R.id.credit_cards) {
                    Intent intent = new Intent(this, CardsActivity.class);
                    startActivity(intent);
                }
                if(menuItem.getItemId() == R.id.credits){
                    Intent intent = new Intent(this, CreditsActivity.class);
                    startActivity(intent);
                }
                if(menuItem.getItemId() == R.id.branches){
                    Intent intent = new Intent(this, BranchesActivity.class);
                    startActivity(intent);
                }
                if(menuItem.getItemId() == R.id.valid_staff){
                    showAlertDialog();
                }
                if(menuItem.getItemId() == R.id.exit_account){
                    Intent intent = new Intent(this, AuthActivity.class);
                    intent.putExtra("exit_user", true);
                    startActivity(intent);
                }

                return false;
            });
        }

    }

    private void showAlertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder (this);
        builder.setTitle (getString(R.string.secret_title));
        View validDialog = getLayoutInflater (). inflate (R.layout.input_code_staff, null);
        builder.setView (validDialog);
        builder.setPositiveButton (getString(R.string.validate), (dialog, which) -> {
            EditText editText = validDialog.findViewById(R.id.edit_text_dialog);
            progressBar = validDialog.findViewById(R.id.progress_valid);
            String code = editText.getText().toString();
            if(code.length() == 10){
                progressBar.setVisibility(View.VISIBLE);
                editText.setVisibility(View.INVISIBLE);
                connect = ConnectorAsync.getConnect();
                if(connect != null) {
                    AuthController controller = new AuthController(context, connect);
                    controller.validUserForStaff(code, user.getId());
                }
            }else
                Toast.makeText(context, R.string.message_valid_code, Toast.LENGTH_SHORT).show();
        });
        builder.setNegativeButton(getString(R.string.close_string), (dialog, which) -> {
            dialog.dismiss();
        });
        AlertDialog dialog = builder.create ();
        dialog.show ();
    }

    @Override
    public void loginUser(Boolean ok, User _user) {
        progressBar.setVisibility(View.GONE);
        if( ok ) {
            if(_user.getRole() == Role.STAFF) navigationView.inflateMenu(R.menu.menu_staff);
            user.setPassword(_user.getPassword());
            user.setEmail(_user.getEmail());
            user.setName(_user.getName());
            user.setId(_user.getId());
            user = _user;
            Toast.makeText(context, getString(R.string.welcom), Toast.LENGTH_SHORT).show();
        }
    }
}
