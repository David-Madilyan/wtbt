package com.mornival.wbtbank.Beans;

public enum Role {
    CLIENT,
    STAFF,
    OWNER
}
