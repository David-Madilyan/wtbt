package com.mornival.wbtbank.Database;

import android.content.Context;
import android.os.AsyncTask;

import com.mornival.wbtbank.Beans.User;
import com.mornival.wbtbank.Callbacks;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AuthController extends AsyncTask<String, Void, Integer> {

    private Callbacks.AuthorizationToDb authCallback = null;
    boolean isLogin;
    Connection connection;
    User user;
    public AuthController(Context context, Connection _connection){
        connection = _connection;
        user = User.getInstance(context);
        authCallback = (Callbacks.AuthorizationToDb) context;
    }

    public void Login(){
        isLogin = true;
        String query = String.format("SELECT * FROM WBTBank.dbo.users WHERE id = '%s'", user.getId());
        execute(query);
    }

    public void validUserForStaff(String code, int id){
        String query = String.format("SELECT * FROM WBTBank.dbo.users WHERE id = '%s' AND code_staff = '%s'", id, code);
        execute(query);
    }
    public void Register(){
        isLogin = false;
        //создать новую таблицу users где автоинкремент для id установить надо
        String query = String.format("INSERT INTO WBTBank.dbo.users VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')",
                user.getName(),
                user.getEmail(),
                user.getPassword(),
                user.getPhone(),
                user.getRole(),
                user.getInn(),
                user.getPassport(),
                user.getSex(),
                user.getCodeStaff(),
                user.getBirthday());
        execute(query);
    }

    @Override
    protected Integer doInBackground(String... query) {
        try {
            Statement stmt = connection.createStatement();
            //посмотреть что приходть с бд, в идеале должен быть экземпляр User
            ResultSet rs = stmt.executeQuery(query[0]);
            return 200;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Integer out) {
        super.onPostExecute(out);
        if(out == 200)
            authCallback.loginUser(true, user);
//        else if(out == 200)
//            authCallback.registerUser(true, user);
    }
}
