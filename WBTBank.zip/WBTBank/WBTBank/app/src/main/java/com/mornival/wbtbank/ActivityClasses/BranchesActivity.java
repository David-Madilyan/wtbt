package com.mornival.wbtbank.ActivityClasses;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.mornival.wbtbank.R;

public class BranchesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_branches);
    }
}
