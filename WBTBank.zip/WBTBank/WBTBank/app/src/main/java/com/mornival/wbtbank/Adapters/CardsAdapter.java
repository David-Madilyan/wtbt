package com.mornival.wbtbank.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mornival.wbtbank.Beans.Card;
import com.mornival.wbtbank.R;
import com.santalu.maskedittext.MaskEditText;

import java.util.ArrayList;

public class CardsAdapter extends RecyclerView.Adapter<CardsAdapter.CardViewHolder> {

    private final Context context;
    private ArrayList<Card> cards;
    public CardsAdapter(Context _context, ArrayList<Card> _cards){
        this.context = _context;
        cards = _cards;
    }
    @NonNull
    @Override
    public CardViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new CardViewHolder(LayoutInflater.from(context).inflate(R.layout.item_card, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull CardViewHolder holder, int position) {
        Card card = cards.get(position);
        holder.bind(card, position);
    }

    @Override
    public int getItemCount() {
        if(cards == null) return 0;
        return cards.size();
    }


    public ArrayList<Card> getCards() {
        return cards;
    }

    public void setCards(ArrayList<Card> cards) {
        this.cards = cards;
        notifyDataSetChanged();
    }

    class CardViewHolder extends RecyclerView.ViewHolder{

        MaskEditText viewNumber, viewDate;
        TextView viewUsername, viewCvv, viewBalance;

        CardViewHolder(@NonNull View itemView) {
            super(itemView);
            viewUsername = itemView.findViewById(R.id.owner_username);
            viewDate = itemView.findViewById(R.id.date_end_card);
            viewNumber = itemView.findViewById(R.id.number_card);
            viewCvv = itemView.findViewById(R.id.cvv_card);
            viewBalance = itemView.findViewById(R.id.balance_card);
        }

        @SuppressLint("SetTextI18n")
        void bind(Card card, int position) {
            viewUsername.setText(card.getUsername());
            viewNumber.setText(card.getNumber());
            viewDate.setText(card.getDate());
            viewCvv.setText(card.getCvv());
            viewBalance.setText(Double.toString(card.getBalance()));
        }
    }
}
