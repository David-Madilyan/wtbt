package com.mornival.wbtbank.Beans;

public enum Role {
    USER,
    STAFF,
    OWNER
}
