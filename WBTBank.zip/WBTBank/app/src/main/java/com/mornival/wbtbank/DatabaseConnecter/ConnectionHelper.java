package com.mornival.wbtbank.DatabaseConnecter;

import android.annotation.SuppressLint;
import android.os.StrictMode;
import android.util.Log;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Objects;

public class ConnectionHelper {

    String ip, db, dbUsername, dbPassword;


    @SuppressLint("NewApi")
    Connection connectionToServer() {

        // Declaring Server ip, username, database name and password
        ip = "192.168.43.139:49172";
        db = "db_greeting";
         dbUsername = "admin";
        dbPassword = "1234";
        // Declaring Server ip, username, database name and password


        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Connection connection = null;
        String ConnectionURL = null;
        try
        {
            ConnectionURL = "jdbc:jtds:sqlserver://"
                    + ip
                    + ";instance=SQLEXPRESS"
                    + ";database=" + db
                    + ";user=" +  dbUsername
                    + ";password=" + dbPassword + ";";
            Class.forName("net.sourceforge.jtds.jdbc.Driver").newInstance();
            connection = DriverManager.getConnection(ConnectionURL);
        }
        catch (SQLException se)
        {
            Log.e("error here 1 : ", Objects.requireNonNull(se.getMessage()));
        }
        catch (ClassNotFoundException e)
        {
            Log.e("error here 2 : ", Objects.requireNonNull(e.getMessage()));
        }
        catch (Exception e)
        {
            Log.e("error here 3 : ", Objects.requireNonNull(e.getMessage()));
        }
        return connection;
    }
}
