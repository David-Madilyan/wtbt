package com.mornival.wbtbank;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RadioGroup;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.mornival.wbtbank.Beans.User;
import com.mornival.wbtbank.DatabaseConnecter.AuthController;
import com.mornival.wbtbank.DatabaseConnecter.ConnectorAsync;
import com.mornival.wbtbank.DatabaseConnecter.GetDataController;
import com.santalu.maskedittext.MaskEditText;

import java.sql.Connection;
import java.util.Objects;
import java.util.UUID;

public class AuthActivity extends AppCompatActivity implements
        Callbacks.ConnectionDb,
        Callbacks.AuthorizationToDb{

    Button loginButton, registerButton, backButton;
    ProgressBar connectionProgress;
    View loginLayout, registerLayout, containerLayout;
    TextInputLayout emailInputLog, passInputLog, emailInputReg, passInputReg, innInput, nameInput, passportInput, phoneInput;
    MaskEditText phoneEdit, birthdayEdit, passportEdit;
    TextInputEditText nameEdit, passwordEditReg, passwordEditLog, emailEditLog, emailEditReg, innEdit, codeEdit;
    RadioGroup radioGroupPol;
    SharedPreferences preferences;
    Connection connect = null;
    Context context;
    User user;

    Boolean isLogin = false, isRegister = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);
        context = this;

        preferences = getSharedPreferences("user_data", MODE_PRIVATE);
        loginButton = findViewById(R.id.login_button);
        registerButton = findViewById(R.id.register_button);
        connectionProgress = findViewById(R.id.progress_connection);
        containerLayout = findViewById(R.id.allViewsLayout);
        loginLayout = findViewById(R.id.layout_login);
        registerLayout = findViewById(R.id.layout_register);
        backButton = findViewById(R.id.back_button);

        //register Views
        nameEdit = findViewById(R.id.editTextUsername);
        passwordEditReg = findViewById(R.id.editTextPasswordReg);
        emailEditReg = findViewById(R.id.editTextEmailReg);
        innEdit = findViewById(R.id.editTextInn);
        phoneEdit = findViewById(R.id.editTextPhone);
        birthdayEdit = findViewById(R.id.editTextBirthday);
        passportEdit = findViewById(R.id.editTextPassport);
        codeEdit = findViewById(R.id.editTextCodeStaff);
        radioGroupPol = findViewById(R.id.radioGroup);
        emailInputReg = findViewById(R.id.til_emailReg);
        passInputReg = findViewById(R.id.til_PasswordReg);
        innInput = findViewById(R.id.til_inn);
        passportInput = findViewById(R.id.til_passport);
        nameInput = findViewById(R.id.til_username);
        phoneInput = findViewById(R.id.til_phone);

        //login Views
        emailInputLog = findViewById(R.id.til_email);
        passInputLog = findViewById(R.id.til_password);
        passwordEditLog = findViewById(R.id.editTextPassword);
        emailEditLog = findViewById(R.id.editTextEmail);


//        connectionProgress.setVisibility(View.GONE);//временно

        user = User.getInstance(context);
        ConnectorAsync connectorAsync = new ConnectorAsync((Callbacks.ConnectionDb) context);
        connectorAsync.execute();

    }

    final View.OnClickListener backListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(loginLayout.getVisibility() == View.VISIBLE){
                loginLayout.setVisibility(View.GONE);
                registerButton.setVisibility(View.VISIBLE);
                isLogin = false;
            }
            if(registerLayout.getVisibility() == View.VISIBLE){
                registerLayout.setVisibility(View.GONE);
                loginButton.setVisibility(View.VISIBLE);
                isRegister = false;
            }
            backButton.setVisibility(View.GONE);
        }
    };

    final View.OnClickListener loginListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if(!isLogin) {
                loginLayout.setVisibility(View.VISIBLE);
                registerButton.setVisibility(View.GONE);
                registerLayout.setVisibility(View.GONE);
                backButton.setVisibility(View.VISIBLE);
                isLogin = true;
            }else{
                if(setDataUserLogin()){
                    //запрос на авторизацию пользователя в системе.
                    //заполнение остальных данных о пользователе прищедщих с бд
                    getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
                    AuthController authController = new AuthController(context, connect);
                    authController.Login();
                }
            }
        }
    };

    private boolean setDataUserLogin() {
        if(Objects.requireNonNull(passwordEditLog.getText()).length() < 7){
            passInputLog.setError(getString(R.string.error_pass));
            return false;
        }else {
            passInputLog.setError("");
            user.setPassword(passwordEditLog.getText().toString());
        }
        if(Objects.requireNonNull(emailEditLog.getText()).length() < 3){
            emailInputLog.setError(getString(R.string.error_pass));
            return false;
        }else {
            emailInputLog.setError("");
            user.setPassword(emailEditLog.getText().toString());
        }
        return true;
    }

    final View.OnClickListener registerListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if(!isRegister){
                registerLayout.setVisibility(View.VISIBLE);
                loginButton.setVisibility(View.GONE);
                loginLayout.setVisibility(View.GONE);
                backButton.setVisibility(View.VISIBLE);
                isRegister = true;
            }else{
                setDataUserRegister();
                if(user.IsValidUser()){
                    AuthController authController = new AuthController(context, connect);
                    authController.Register();
                    getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
                    connectionProgress.setVisibility(View.VISIBLE);
                }
            }
        }
    };

    private void setDataUserRegister() {
        if(Objects.requireNonNull(emailEditReg.getText()).length() < 3){
            emailInputReg.setError(getString(R.string.error_auth));
        }else {
            emailInputReg.setError("");
            user.setEmail(emailEditReg.getText().toString());
        }

        if(Objects.requireNonNull(passwordEditReg.getText()).length() < 7){
            passInputReg.setError(getString(R.string.error_pass));
        }else {
            passInputReg.setError("");
            user.setPassword(passwordEditReg.getText().toString());
        }

        if(Objects.requireNonNull(nameEdit.getText()).length() == 0){
            nameInput.setError(getString(R.string.error_auth));
        }else {
            nameInput.setError("");
            user.setName(nameEdit.getText().toString());
        }

        if(Objects.requireNonNull(innEdit.getText()).length() == 0){
            innInput.setError(getString(R.string.error_auth));
        }else {
            innInput.setError("");
            user.setInn(innEdit.getText().toString());
        }

        if(Objects.requireNonNull(passportEdit.getText()).length() == 0){
            passportInput.setError(getString(R.string.error_auth));
        }else {
            passportInput.setError("");
            user.setPassport(passportEdit.getText().toString());
        }

        if(Objects.requireNonNull(phoneEdit.getText()).length() == 0){
            phoneInput.setError(getString(R.string.error_auth));
        }else {
            phoneInput.setError("");
            user.setPhone(phoneEdit.getText().toString());
        }

        if(Objects.requireNonNull(codeEdit.getText()).length() > 0){
            user.setCodeStaff(codeEdit.getText().toString());
        }

        if(Objects.requireNonNull(birthdayEdit.getText()).length() > 0){
            user.setBirthday(birthdayEdit.getText().toString());
        }

        if(radioGroupPol.getCheckedRadioButtonId() == R.id.radio_female)
            user.setSex("жен");
        else if(radioGroupPol.getCheckedRadioButtonId() == R.id.radio_male)
            user.setSex("муж");
        else
            user.setSex("не указан");
    }

    @Override
    public void connectedToDatabase(Connection _connect, Boolean ok) {
        if(ok){
            containerLayout.setVisibility(View.VISIBLE);
            connect = _connect;
            if(user.getPassword() != null && user.getEmail() != null){
                AuthController authController = new AuthController(context, connect);
                authController.Login();
            }else{
                connectionProgress.setVisibility(View.GONE);
                containerLayout.setVisibility(View.VISIBLE);
                loginButton.setOnClickListener(loginListener);
                registerButton.setOnClickListener(registerListener);
                backButton.setOnClickListener(backListener);
            }

        } else{
            connectionProgress.setVisibility(View.GONE);
            AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
            alertDialog.setMessage(R.string.failed_connection);
            alertDialog.setPositiveButton(R.string.close_string, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                }
            });
            alertDialog.create().show();
        }
    }

    @Override
    public void loginUser(Boolean ok, User _user) {
        connectionProgress.setVisibility(View.GONE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

//      обновить данные о пользователе так, как с бд прейдут новые данные, а поле user не обновлялось
//      Intent intent = new Intent(AuthActivity.this, MainActivity.class);
//      startActivity(intent);
    }

    @Override
    public void registerUser(Boolean ok, User _user) {
        connectionProgress.setVisibility(View.GONE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

//      Intent intent = new Intent(AuthActivity.this, MainActivity.class);
//      startActivity(intent);
    }
}
