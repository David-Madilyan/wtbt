package com.mornival.wbtbank;

import com.mornival.wbtbank.Beans.User;

import java.sql.Connection;

public interface Callbacks {

    interface ConnectionDb{
        void connectedToDatabase(java.sql.Connection connect, Boolean isOk);
    }

    interface AuthorizationToDb{
        void loginUser(Boolean ok, User user);
        void registerUser(Boolean ok, User user);
    }

}
