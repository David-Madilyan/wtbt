package com.mornival.wbtbank.DatabaseConnecter;

import android.os.AsyncTask;
import android.util.Log;

import com.mornival.wbtbank.Callbacks;

import java.sql.Connection;
import java.util.Objects;

public class ConnectorAsync extends AsyncTask<String, Void, Integer> {

    private Connection connect = null;
    private Callbacks.ConnectionDb connectCallback;

    public ConnectorAsync(Callbacks.ConnectionDb _callback){
        connectCallback = _callback;
    }
    @Override
    protected Integer doInBackground(String... strings) {
        try{
            ConnectionHelper connectionHelper = new ConnectionHelper();
            connect = connectionHelper.connectionToServer();

        }catch (Exception ex){
            Log.e("connect failure", Objects.requireNonNull(ex.getMessage()));
        }
        return null;
    }

    @Override
    protected void onPostExecute(Integer out) {
        super.onPostExecute(out);
        if(connect == null){
            connectCallback.connectedToDatabase(null, false);
        }else{
            connectCallback.connectedToDatabase(connect, true);
        }
    }
}
