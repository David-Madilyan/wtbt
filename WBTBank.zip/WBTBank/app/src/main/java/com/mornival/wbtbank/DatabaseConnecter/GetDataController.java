package com.mornival.wbtbank.DatabaseConnecter;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/* здесь будут описаны все методы взаимодествия с базой данных*/
public class GetDataController {
    Connection connect;
    String ConnectionResult = "";
    Boolean isSuccess = false;

    public List<Map<String, String>> doInBackground() {

        List<Map<String, String>> data  = new ArrayList<>();
        try
        {
//            ConnectionHelper conStr = new ConnectionHelper();
//            connect = conStr.connectionclasss();        // Connect to database
            if (connect == null)
            {
                ConnectionResult = "Check Your Internet Access!";
            }
            else
            {
                System.out.println("connection to database is OK");
                // Change below query according to your own database.
                String query = "select * from db_greeting.dbo.messages";
                Statement stmt = connect.createStatement();
                ResultSet rs = stmt.executeQuery(query);

                while (rs.next()){
                    Map<String, String> datanum = new HashMap<>();
                    datanum.put("m_tag",rs.getString("tag"));
                    datanum.put("m_text",rs.getString("text"));
                    data.add(datanum);
                }
                ConnectionResult = " successful";
                isSuccess = true;
                connect.close();
            }
        }
        catch (Exception ex)
        {
            isSuccess = false;
            ConnectionResult = ex.getMessage();
        }

        return data;
    }
}
