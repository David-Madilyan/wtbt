package com.mornival.wbtbank.DatabaseConnecter;

import android.content.Context;
import android.os.AsyncTask;

import com.mornival.wbtbank.Beans.User;
import com.mornival.wbtbank.Callbacks;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AuthController extends AsyncTask<String, Void, Integer> {

    private Callbacks.AuthorizationToDb authCallback = null;
    boolean isLogin;
    Connection connection;
    User user;
    public AuthController(Context context, Connection _connection){
        connection = _connection;
        user = User.getInstance(context);
        authCallback = (Callbacks.AuthorizationToDb) context;
    }

    public void Login(){
        isLogin = true;
        String query = String.format("SELECT * FROM wbtbank.dbo.users WHERE id = '%s'", user.getId());
        execute(query);
    }
    public void Register(){
        isLogin = false;
        String query = String.format("INSERT INTO wbtbank.dbo.users VALUES ('%s', '%s', %s, %s)", user.getName());
        execute(query);
    }

    @Override
    protected Integer doInBackground(String... query) {
        try {
            Statement stmt = connection.createStatement();
            //посмотреть что приходть с бд
            ResultSet rs = stmt.executeQuery(query[0]);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Integer out) {
        super.onPostExecute(out);
        if(isLogin && out == 200)
            authCallback.loginUser(true, user);
        else
            authCallback.registerUser(true, user);
    }
}
