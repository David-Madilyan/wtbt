package com.mornival.wbtbank;

public class Crypto {

    /* Данное шифрование является примером того как можно реализовать данную архитектуру в приложении,
     * методы Encrypt и Decrypt  одинаковые и служат только в качестве показательного примера
     * естественно  можно применять любое симметричное шифвароние какое актуально на данное время
     * */

    public Crypto(){ }

    private String Encrypt (String _key, String mes){
        char[] key = _key.toCharArray();
        char[] message = mes.toCharArray();
        StringBuilder enStr = new StringBuilder();
        int keyLen = key.length;
        for(int i = 0; i < message.length; i++){
            enStr.append(message[i] ^ key[i % keyLen]);
        }
        return enStr.toString();
    }

    private String Decrypt (String _key, String mes){
        char[] key = _key.toCharArray();
        char[] message = mes.toCharArray();
        StringBuilder enStr = new StringBuilder();
        int keyLen = key.length;
        for(int i = 0; i < message.length; i++){
            enStr.append(message[i] ^ key[i % keyLen]);
        }
        return enStr.toString();
    }
}
